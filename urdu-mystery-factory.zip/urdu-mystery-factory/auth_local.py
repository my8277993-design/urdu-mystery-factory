"""
Run ONCE on your own computer to authorize your YouTube channel.
Download OAuth Desktop-app client JSON from Google Cloud and save it as client_secret.json.
Then run: python auth_local.py
It creates token.json. Keep it private; never commit it to GitHub.
"""
from google_auth_oauthlib.flow import InstalledAppFlow
import json

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", SCOPES)
creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")
with open("token.json", "w", encoding="utf-8") as f:
    f.write(creds.to_json())

print("Created token.json. Keep it secret; do not share or commit it.")
