# Urdu Mystery Factory

A scheduled GitHub Actions project that creates Urdu history/mystery videos, Pakistani Urdu male narration, subtitles, thumbnails, and scheduled YouTube uploads.

## Important limitations

- This is a best-effort **$0 prototype**, not unlimited hosting. Groq, Pexels, GitHub Actions, and YouTube quotas/policies can change.
- Microsoft Edge TTS is an unofficial client of an online service. It is not a contractual, unlimited commercial TTS API. Check Microsoft's terms and current usage rules before monetizing.
- Historical content is grounded in a Wikipedia article extract, but AI can still make mistakes. Review early outputs and improve source checking before trusting unattended publishing.
- Pexels stock clips are illustrative, not archival proof of the event being narrated. The description credits Pexels.
- GitHub scheduled workflows can be delayed or skipped during high load. The app schedules publication for the next Pakistan-time day.
- YouTube's November 2, 2026 API revision says uploads from unverified API projects are no longer restricted to private mode. Scheduled publication still requires valid OAuth authorization and a future `publishAt` timestamp. Check current API rules if this changes.
- YouTube can reject or restrict repetitive, mass-produced, misleading, or reused content. Automation does not guarantee monetization.

## Publishing schedule

The workflow runs daily at 15:00 Pakistan time:
- Every day: one Urdu Short, scheduled for 17:00 the following Pakistan-time day.
- Monday and Thursday: also one 5–7 minute long video, scheduled for 20:00 the following day (Tuesday and Friday).
- Uploads are created as private with `publishAt`; YouTube publishes them at the scheduled time.

## 1. Create accounts and keys

1. Create a GitHub account and a **public** repository (Actions on standard GitHub-hosted runners are free for public repositories).
2. Create a Groq API key at https://console.groq.com/keys.
3. Create a Pexels API key at https://www.pexels.com/api/.
4. In Google Cloud Console:
   - Create a project.
   - Enable **YouTube Data API v3**.
   - Configure the OAuth consent screen. For a personal channel, use External audience and add yourself as a user during setup.
   - Create OAuth Client ID → **Desktop app**.
   - Download the client JSON and rename it to `client_secret.json`.
   - If you leave an External app in **Testing**, its refresh token expires after 7 days for YouTube upload scopes. After you have tested sign-in, change Publishing status to **In production** for your personal-use app (under 100 known users). You may see an unverified-app warning; proceed only for your own app after checking its identity. Google says personal-use apps can be exempt from verification, but the warning/user cap can apply.

## 2. Create the YouTube OAuth token (one-time)

On your own computer, install Python 3.11+, then in this folder run:

```bash
pip install -r requirements.txt
python auth_local.py
```

A browser opens. Sign in with the Google account that owns your YouTube channel and grant YouTube upload permission. This creates `token.json`.

Never upload `client_secret.json` or `token.json` to a public GitHub repository.

## 3. Add GitHub Actions secrets

In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.

Add these three secrets:

- `GROQ_API_KEY` = your Groq key (plain text).
- `PEXELS_API_KEY` = your Pexels key (plain text).
- `GOOGLE_TOKEN_JSON_B64` = base64-encoded contents of `token.json`. The token file contains the OAuth client details needed by the Google library.

### Base64 commands

macOS/Linux:
```bash
base64 -w 0 token.json
```

macOS may not support `-w 0`; use:
```bash
base64 < token.json | tr -d '\n'
```

Windows PowerShell:
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("token.json"))
```

Copy the token output into the `GOOGLE_TOKEN_JSON_B64` secret. Do not paste credentials into chat or commit them.

## 4. Upload these project files to GitHub

Upload the contents of this ZIP to the root of your repository. Ensure `.github/workflows/publish.yml` is in the exact path.

## 5. Enable and test

1. Open the repository's **Actions** tab.
2. If prompted, enable workflows.
3. Choose **Urdu Mystery Factory** → **Run workflow**.
4. Wait for the run to finish. Inspect logs if it fails.
5. Check YouTube Studio → Content → Scheduled.

The first manual run also follows the same schedule rules; it does not publish immediately.

## 6. Customize

- Change topics in `data/topics.json`.
- Change `GROQ_MODEL` in the workflow if Groq changes its model availability.
- Change `TTS_VOICE` to `ur-PK-UzmaNeural` for the female voice.
- Edit the weekly long-video days in `main.py` (`now.weekday() in (0,3)` means Monday and Thursday).
- Edit publish hours in `main.py` (`next_publish_time(17)` for Shorts and `(20)` for long videos).

## Troubleshooting

- **Groq 401/429**: key invalid or free-tier rate limit reached. Retry later or select a currently available model in Groq console.
- **Pexels 401/429**: check key and API quota.
- **Google invalid_grant**: repeat `python auth_local.py`, then update `GOOGLE_TOKEN_JSON_B64`.
- **YouTube upload is private / cannot schedule public**: check channel eligibility, OAuth consent, API audit status and YouTube Studio restrictions.
- **No subtitles/font**: ensure workflow installs `fonts-noto-core` and FFmpeg has libass support.
- **Bad visuals**: Pexels results are approximate stock footage. Change the `pexels`/visual query for the topic or curate the footage manually.

## Attribution

Stock footage is retrieved from Pexels. See https://www.pexels.com and its API documentation: https://www.pexels.com/api/documentation/.
