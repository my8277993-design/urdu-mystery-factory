import os, json, re, random, asyncio, base64, textwrap, subprocess, sys, time
from pathlib import Path
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import requests
import edge_tts
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

ROOT = Path(__file__).parent
WORK = ROOT / "work"
WORK.mkdir(exist_ok=True)
PK = ZoneInfo("Asia/Karachi")
VOICE = os.getenv("TTS_VOICE", "ur-PK-AsadNeural")
GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b")
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

def require_env(name):
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Missing GitHub Actions secret/environment variable: {name}")
    return value

def choose_topic():
    topics = json.loads((ROOT / "data/topics.json").read_text(encoding="utf-8"))
    # Stable daily rotation avoids repeatedly choosing the same topic on workflow retries.
    day_index = datetime.now(PK).date().toordinal()
    return topics[day_index % len(topics)]

def wikipedia_context(query):
    headers = {"User-Agent": "UrduMysteryFactory/1.0 (educational video project)"}
    r = requests.get("https://en.wikipedia.org/w/api.php", params={
        "action":"query", "list":"search", "srsearch":query, "format":"json", "srlimit":5
    }, headers=headers, timeout=30)
    r.raise_for_status()
    hits = r.json().get("query", {}).get("search", [])
    if not hits:
        raise RuntimeError("No Wikipedia source found for topic: " + query)
    # Prefer the first result; retain its exact URL for the video description.
    title = hits[0]["title"]
    page = requests.get("https://en.wikipedia.org/w/api.php", params={
        "action":"query", "prop":"extracts", "explaintext":1, "exintro":0,
        "titles":title, "format":"json", "redirects":1
    }, headers=headers, timeout=30)
    page.raise_for_status()
    pages = page.json().get("query", {}).get("pages", {})
    page_data = next(iter(pages.values()))
    extract = re.sub(r"\s+", " ", page_data.get("extract", "")).strip()
    if len(extract) < 500:
        raise RuntimeError("Source extract too short; refusing to invent a history script.")
    url = "https://en.wikipedia.org/wiki/" + requests.utils.quote(title.replace(" ", "_"))
    return title, extract[:11000], url

def groq_json(prompt):
    key = require_env("GROQ_API_KEY")
    response = requests.post("https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type":"application/json"},
        json={
            "model": GROQ_MODEL,
            "temperature": 0.55,
            "response_format": {"type":"json_object"},
            "messages":[
                {"role":"system","content":(
                    "You are a careful Urdu documentary writer. Write natural Pakistani Urdu in Urdu script. "
                    "Use ONLY the supplied source extract for factual claims. Never invent dates, quotes, people, "
                    "causes, eyewitness accounts or supernatural explanations. Separate established facts from "
                    "theories and say when evidence is uncertain. Do not copy source wording. Return valid JSON only."
                )},
                {"role":"user","content":prompt}
            ],
            "max_tokens": 7000
        }, timeout=180)
    if response.status_code >= 400:
        raise RuntimeError(f"Groq API error {response.status_code}: {response.text[:1200]}")
    content = response.json()["choices"][0]["message"]["content"]
    return json.loads(content)

def make_scripts(topic, source_title, extract, source_url, include_long):
    prompt = f"""
Topic: {topic['title']}
Wikipedia source title: {source_title}
Source URL: {source_url}
SOURCE EXTRACT (factual grounding; do not go beyond it):
{extract}

Create JSON with:
{{
 "long": {{
   "title": "Urdu title, max 85 characters",
   "script": "A compelling 5-7 minute Urdu documentary narration, approximately 650-850 Urdu words. Include a hook, chronological explanation, what is known, what remains uncertain, and a balanced ending. No fabricated cliffhangers.",
   "description": "Urdu description, source URL included, plus Pexels attribution link https://www.pexels.com",
   "visual_query": "3-5 simple English words for relevant stock footage",
   "tags": ["Urdu history", "mystery", "documentary"]
 }},
 "short": {{
   "title": "Urdu Shorts title, max 85 characters",
   "script": "A standalone 45-60 second Urdu short narration, around 100-130 words, accurate and engaging.",
   "description": "Short Urdu description with source URL and Pexels attribution link",
   "visual_query": "3-5 simple English words for relevant portrait footage",
   "tags": ["Urdu shorts", "history", "mystery"]
 }}
}}
If include_long is false, still return both keys but long.script can be an empty string.
include_long={str(include_long).lower()}
"""
    data = groq_json(prompt)
    if not isinstance(data.get("short", {}).get("script"), str) or len(data["short"]["script"]) < 150:
        raise RuntimeError("AI returned an incomplete Short script.")
    if include_long and len(data.get("long", {}).get("script", "")) < 1800:
        raise RuntimeError("AI returned an incomplete long-video script.")
    return data

def get_pexels_video(query, portrait):
    key = require_env("PEXELS_API_KEY")
    orientation = "portrait" if portrait else "landscape"
    r = requests.get("https://api.pexels.com/videos/search",
        headers={"Authorization":key},
        params={"query":query or "historical ruins cinematic", "per_page":12, "orientation":orientation},
        timeout=45)
    r.raise_for_status()
    videos = r.json().get("videos", [])
    if not videos:
        r = requests.get("https://api.pexels.com/videos/search",
            headers={"Authorization":key},
            params={"query":"historical ruins cinematic", "per_page":12, "orientation":orientation},
            timeout=45)
        r.raise_for_status()
        videos = r.json().get("videos", [])
    if not videos:
        raise RuntimeError("Pexels returned no matching stock footage.")
    random.shuffle(videos)
    for video in videos:
        files = sorted(video.get("video_files", []),
                       key=lambda x: (x.get("width",0), x.get("height",0)), reverse=True)
        for vf in files:
            link = vf.get("link","")
            if link.endswith(".mp4") or "video_files" in link:
                out = WORK / ("background_portrait.mp4" if portrait else "background_landscape.mp4")
                with requests.get(link, stream=True, timeout=90) as dl:
                    dl.raise_for_status()
                    with open(out, "wb") as f:
                        for chunk in dl.iter_content(1024*1024):
                            if chunk: f.write(chunk)
                if out.stat().st_size > 500_000:
                    return out, video.get("url","https://www.pexels.com")
    raise RuntimeError("Could not download a usable Pexels MP4.")

async def make_voice(script, name):
    audio = WORK / f"{name}.mp3"
    srt = WORK / f"{name}.srt"
    communicate = edge_tts.Communicate(script, VOICE, rate="-5%")
    await communicate.save(str(audio), str(srt))
    if not audio.exists() or audio.stat().st_size < 10000:
        raise RuntimeError("TTS did not produce a valid audio file.")
    return audio, srt

def duration_seconds(audio):
    result = subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
        "-of","default=noprint_wrappers=1:nokey=1",str(audio)], capture_output=True, text=True, check=True)
    return float(result.stdout.strip())

def render_video(script_obj, kind, source_url):
    portrait = kind == "short"
    name = kind
    audio, srt = asyncio.run(make_voice(script_obj["script"], name))
    bg, pexels_url = get_pexels_video(script_obj.get("visual_query","historical ruins"), portrait)
    out = WORK / f"{name}.mp4"
    if portrait:
        scale_crop = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
        fontsize, margin = 26, 90
    else:
        scale_crop = "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080"
        fontsize, margin = 30, 70
    vf = (f"{scale_crop},subtitles={srt.name}:"
          f"force_style='FontName=Noto Naskh Arabic,FontSize={fontsize},"
          f"Outline=2,Shadow=1,Alignment=2,MarginV={margin}'")
    cmd = ["ffmpeg","-y","-stream_loop","-1","-i",str(bg),"-i",str(audio),
           "-vf",vf,"-map","0:v:0","-map","1:a:0","-c:v","libx264",
           "-preset","veryfast","-crf","25","-pix_fmt","yuv420p",
           "-c:a","aac","-b:a","128k","-shortest","-movflags","+faststart",str(out)]
    subprocess.run(cmd, cwd=WORK, check=True)
    if not out.exists() or out.stat().st_size < 100000:
        raise RuntimeError("FFmpeg failed to render a usable video.")
    thumb = WORK / f"{name}_thumbnail.jpg"
    make_thumbnail(bg, script_obj["title"], thumb, portrait)
    description = script_obj.get("description","") + (
        f"\n\nتحقیق کے لیے ماخذ: {source_url}\n"
        f"ویڈیو فوٹیج: Photos and videos provided by Pexels — https://www.pexels.com"
        "\nیہ ویڈیو تعلیمی اور معلوماتی مقصد کے لیے AI کی مدد سے تیار کی گئی ہے۔"
    )
    return out, thumb, description, pexels_url

def make_thumbnail(background, title, output, portrait):
    # Create 16:9 thumbnail for both formats, with the vertical video frame as a source if needed.
    subprocess.run(["ffmpeg","-y","-i",str(background),"-frames:v","1",str(WORK/"thumb_frame.jpg")],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    img = Image.open(WORK/"thumb_frame.jpg").convert("RGB").resize((1280,720))
    img = ImageEnhance.Brightness(img).enhance(0.48)
    overlay = Image.new("RGBA", img.size, (0,0,0,70))
    img = Image.alpha_composite(img.convert("RGBA"), overlay)
    draw = ImageDraw.Draw(img)
    font_path = "/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf"
    try:
        font = ImageFont.truetype(font_path, 76)
    except Exception:
        font = ImageFont.load_default()
    # Wrap Urdu title into short lines; PIL uses RAQM when available.
    words, lines, line = title.split(), [], ""
    for word in words:
        candidate = (line + " " + word).strip()
        if len(candidate) > 22 and line:
            lines.append(line); line = word
        else:
            line = candidate
    if line: lines.append(line)
    lines = lines[:3]
    y = 230 if len(lines) == 1 else 170
    for line in lines:
        try:
            draw.text((1180,y), line, font=font, fill="white", anchor="ra",
                      direction="rtl", language="ur", stroke_width=3, stroke_fill="#111111")
        except TypeError:
            draw.text((1180,y), line, font=font, fill="white", anchor="ra",
                      stroke_width=3, stroke_fill="#111111")
        y += 105
    img.convert("RGB").save(output, quality=92)

def youtube_client():
    token_b64 = require_env("GOOGLE_TOKEN_JSON_B64")
    token_info = json.loads(base64.b64decode(token_b64).decode("utf-8"))
    creds = Credentials.from_authorized_user_info(token_info, SCOPES)
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
    if not creds.valid:
        raise RuntimeError("YouTube OAuth token invalid. Regenerate token.json and update GitHub secret.")
    return build("youtube","v3",credentials=creds,cache_discovery=False)

def next_publish_time(hour):
    now = datetime.now(PK)
    publish = (now + timedelta(days=1)).replace(hour=hour, minute=0, second=0, microsecond=0)
    if publish <= now + timedelta(minutes=45):
        publish += timedelta(days=1)
    return publish.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")

def upload_video(youtube, video_path, thumbnail_path, title, description, tags, publish_at, short):
    body = {
        "snippet":{
            "title":title[:100],
            "description":description[:4900],
            "tags":(tags or [])[:15] + (["Shorts"] if short else []),
            "categoryId":"27",
            "defaultLanguage":"ur",
            "defaultAudioLanguage":"ur"
        },
        "status":{
            "privacyStatus":"private",
            "publishAt":publish_at,
            "selfDeclaredMadeForKids":False
        }
    }
    media = MediaFileUpload(str(video_path), mimetype="video/mp4", chunksize=8*1024*1024, resumable=True)
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"Upload progress: {int(status.progress()*100)}%")
    video_id = response["id"]
    # YouTube may not accept a custom thumbnail until video processing finishes.
    try:
        for attempt in range(30):
            info = youtube.videos().list(part="status,processingDetails", id=video_id).execute()
            items = info.get("items", [])
            if items:
                processing = items[0].get("processingDetails", {}).get("processingStatus")
                upload_status = items[0].get("status", {}).get("uploadStatus")
                if processing == "succeeded" or upload_status == "processed":
                    youtube.thumbnails().set(
                        videoId=video_id,
                        media_body=MediaFileUpload(str(thumbnail_path), mimetype="image/jpeg")
                    ).execute()
                    print("Custom thumbnail uploaded.")
                    break
                if processing in ("failed", "terminated"):
                    print("YouTube processing failed; skipping custom thumbnail.")
                    break
            time.sleep(30)
        else:
            print("Thumbnail not ready before timeout; YouTube will use its generated thumbnail.")
    except Exception as exc:
        print("Thumbnail upload warning:", exc)
    print(f"Scheduled {title} — https://youtu.be/{video_id} — {publish_at}")

def main():
    topic = choose_topic()
    now = datetime.now(PK)
    # Runs at 15:00 Pakistan time daily. Monday/Thursday runs prepare Tuesday/Friday long episodes.
    make_long = now.weekday() in (0,3)
    print("Topic:", topic["title"], "| long video:", make_long)
    source_title, extract, source_url = wikipedia_context(topic["search"])
    scripts = make_scripts(topic, source_title, extract, source_url, make_long)
    youtube = youtube_client()

    short_video, short_thumb, short_desc, _ = render_video(scripts["short"], "short", source_url)
    short_publish = next_publish_time(17)
    upload_video(youtube, short_video, short_thumb, scripts["short"]["title"],
                 short_desc, scripts["short"].get("tags",[]), short_publish, True)

    if make_long:
        long_video, long_thumb, long_desc, _ = render_video(scripts["long"], "long", source_url)
        long_publish = next_publish_time(20)
        upload_video(youtube, long_video, long_thumb, scripts["long"]["title"],
                     long_desc, scripts["long"].get("tags",[]), long_publish, False)

if __name__ == "__main__":
    main()
